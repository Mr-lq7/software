import os
from datetime import timedelta
from flask import Flask, url_for, render_template, request, redirect, session
from flask import jsonify
from flask import g
import json
import test111
from model import User
import process_data
import connect_sql

from flask_cors import CORS

app = Flask(__name__)
CORS(app, supports_credentials=True)
# ctx = app.app_context()
# ctx.push()

app.config['SECRET_KEY'] = os.urandom(24)
#app.secret_key(os.urandom(24))
head1 = ['username', 'password', 'root', 'mailbox']
head2 = ['REPORT_NUM', 'EVENT_PROPERTY_NAME', 'EVENT_TYPE_ID', 'EVENT_TYPE_NAME', 'EVENT_SRC_NAME',
         'DISTRICT_ID', 'INTIME_ARCHIVE_NUM', 'SUB_TYPE_ID', 'DISTRICT_NAME', 'COMMUNITY_ID', 'REC_ID',
         'STREET_ID', 'OVERTIME_ARCHIVE_NUM', 'OPERATE_NUM', 'DISPOSE_UNIT_ID', 'STREET_NAME', 'CREATE_TIME',
         'EVENT_SRC_ID', 'INTIME_TO_ARCHIVE_NUM', 'SUB_TYPE_NAME',
         'EVENT_PROPERTY_ID', 'OCCUR_PLACE', 'COMMUNITY_NAME', 'DISPOSE_UNIT_NAME',
         'MAIN_TYPE_NAME', 'MAIN_TYPE_ID']
sql_2 = connect_sql.Sql('user_info')
sql_1 = connect_sql.Sql('project_data')
df = sql_1.read_database('project_data',head2)
date = {'year': 2018, 'month': 10, 'day': 30}
df_new = process_data.time_simulation(date,df,head2)
df = process_data.deletedate(date,df)

All_user = sql_2.read_database('user_info',head1)

@app.route('/login', methods=['GET','POST'])
def index(name=None):

    if request.method == "POST":
        info1 = request.get_json()
        data1 = process_data.User_Check(All_user, info1)
        if data1['answer'] == '0':
            session['username'] = info1['username']
            session['cnt'] = 0
        return jsonify(data1)
    #session.permanent = True
    #app.permanent_session_lifetime = timedelta(minutes=5)
    return render_template('login.html')

@app.route('/charts', methods=['GET','POST'])
def user_login():
    if not session.get("username"):
        return redirect('/login')
    if request.method == 'POST':
        info2 = request.get_json()

        if info2['order'] == 1:
            cnt = session['cnt']
            k = len(df)
            if cnt < 80:
                df.loc[k] = df_new.loc[cnt]
                session['cnt'] += 1
                if session['cnt'] == 80:
                    session['cnt'] = 80
                    cnt = 80
            else:
                session['cnt'] = 80
                pass
            data2 = process_data.ABE_sim(df_new,cnt)
            return jsonify(data2)

        elif info2['order'] == 2:
            data2 = process_data.EVENT_PROPERTY(df, info2)
            return jsonify(data2)
        elif info2['order'] == 3:
            data2 = process_data.STREET_MAIN_TYPE(df, info2)
            return jsonify(data2)
        elif info2['order'] == 4:
            data2 = process_data.Hot_Community(df, info2)
            return jsonify(data2)
        elif info2['order'] == 5:
            data2 = process_data.Handling_problems(df, info2)
            return jsonify(data2)
        elif info2['order'] == 6:
            va = process_data.return_root(All_user,session['username'])
            return jsonify({'name':session['username'], 'root':va})

        elif info2['order'] == 7:
            data2=process_data.effic_of_deptm(df, info2)
            return jsonify(data2)
        elif info2['order'] == 8:
            data2 = process_data.change_password(All_user, info2, sql_2)
            return jsonify(data2)

        elif info2['order'] == 9:
            data2 = process_data.judge_account(All_user, info2)
            return jsonify(data2)

        elif info2['order'] == 10:
            data2 = process_data.find_password(All_user, info2)
            return jsonify(data2)
        elif info2['order'] == 11:
            data2 = process_data.regist_account(All_user,info2,sql_2)
            return jsonify(data2)
        elif info2['order'] == 12:
            data2 = process_data.withdraw_account(All_user, info2, sql_2)
            return jsonify(data2)
    if session.get("username"):
        return render_template('home.html')
    # else:
    #     return render_template('login.html')
        #redirect('/')


@app.route('/logout/', methods=['POST','GET'])
def logout():
    session.clear()
    return redirect('/login')
    #return render_template('login.html')


if __name__ == '__main__':
    #app.run(debug=True)
    #print(url_for("index"))
    app.run(host='0.0.0.0',port=5000,debug=True)
    # with app.test_request_context():
    #     print(url_for("hello_world", username='fgooo'))
    #     print(url_for("hello_world1", username= 'nmsl'))






















