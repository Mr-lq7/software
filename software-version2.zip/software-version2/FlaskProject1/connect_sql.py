import pymysql.cursors
import pymysql
import pandas as pd
from pandas import DataFrame
from sqlalchemy import create_engine
import sqlalchemy
from werkzeug.security import generate_password_hash,check_password_hash
import process_data

class Sql():
    def __init__(self, name):
        self.config = {
            'host': '127.0.0.1',
            'port': 3306,  # MySQL默认端口
            'user': 'root',  # mysql默认用户名
            'password': 'rjgc555',
            'db': 'test',  # 数据库
            'charset': 'utf8mb4',
        }
        self.con = pymysql.connect(**self.config)
        self.sql_global = "select * from " + str(name)

    def read_database(self, name, head):
        try:
            with self.con.cursor() as cursor:
                cursor.execute(self.sql_global)
                result = cursor.fetchall()
        except Exception as e:
            raise e
        finally:
            df = pd.DataFrame(result)  # 转换成DataFrame格式,比较好处理
            df.columns = head
            cursor.close()
            return df

    #####data格式[("sss", "fsfe55","0"), ("ssps", "fsfe5590","0")]
    ##前面是用户名，后面是密码(用哈希加盐过的)
    def insert_database(self, name, data):
        cursor = self.con.cursor()
        # sql_insert = "insert into user_info(ID,PSD) values('liu','1234')"
        # 多条插入一起执行
        # rows = cursor.executemany("insert into user_info(ID, PSD) "
        #                                "values (%s, %s)",data)
        sql_insert = "insert into " + str(name) + "(username,password,root,mailbox) values(%s,%s,%s,%s)"  # 要插入的数据
        try:
            cursor.executemany(sql_insert, data)
            # 提交
            self.con.commit()
            cursor.execute(self.sql_global)
            result = cursor.fetchall()
        except Exception as e:
            #    # 错误回滚
            self.con.rollback()
        finally:
            cursor.close()

    ##data格式data = [("789", '1',"sss"), ("777777",'1',"ssps")]
    ##前面是密码(用哈希加盐过的)，后面是用户名
    def update_database(self, name, data):

        # 使用cursor()方法获取操作游标
        cursor = self.con.cursor()

        sql_update = "update " + str(name) + " set password = '%s' ,root = '%s', mailbox = '%s' where username = '%s'"

        # try:
        for item in data:
            cursor.execute(sql_update % item)  # 像sql语句传递参数
        # cursor.executemany(sql_update, data)
        # 提交
        self.con.commit()
        cursor.execute(self.sql_global)
        # except Exception as e:
        # 错误回滚
        self.con.rollback()
        # finally:
        cursor.close()


    ###data格式data=[('sss')]用户名
    def delete_database(self, name, data):
        # self.con = pymysql.connect(**config)
        cursor = self.con.cursor()
        sql_delete = "delete from " + str(name) + " where username ='%s'"

        try:
            for item in data:
                cursor.execute(sql_delete % (item))  # 像sql语句传递参数
            # 提交
            self.con.commit()
            cursor.execute(self.sql_global)
        except Exception as e:
            # 错误回滚
            self.con.rollback()
        finally:
            pass
            cursor.close()

    def end(self):
        self.con.close()


head1 = ['username', 'password', 'root', 'mailbox']
head2 = ['REPORT_NUM', 'EVENT_PROPERTY_NAME', 'EVENT_TYPE_ID', 'EVENT_TYPE_NAME', 'EVENT_SRC_NAME',
         'DISTRICT_ID', 'INTIME_ARCHIVE_NUM', 'SUB_TYPE_ID', 'DISTRICT_NAME', 'COMMUNITY_ID', 'REC_ID',
         'STREET_ID', 'OVERTIME_ARCHIVE_NUM', 'OPERATE_NUM', 'DISPOSE_UNIT_ID', 'STREET_NAME', 'CREATE_TIME',
         'EVENT_SRC_ID', 'INTIME_TO_ARCHIVE_NUM', 'SUB_TYPE_NAME',
         'EVENT_PROPERTY_ID', 'OCCUR_PLACE', 'COMMUNITY_NAME', 'DISPOSE_UNIT_NAME',
         'MAIN_TYPE_NAME', 'MAIN_TYPE_ID']
# data = {}
# sql = Sql('user_info')
# All_user = sql.read_database('user_info',head1)
# print(All_user)
# data['username'] = 'erree'
# data['password'] = '12346546'
# data['mailbox'] = 'dfsff@qq.com'
# process_data.regist_account(All_user, data, sql)
# All_user = sql.read_database('user_info',head1)
# print(All_user)
