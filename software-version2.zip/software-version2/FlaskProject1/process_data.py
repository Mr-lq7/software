# -*- coding: utf-8 -*-
from datetime import datetime
from flask import request
import pandas as pd
from dateutil.parser import parse
from werkzeug.security import generate_password_hash,check_password_hash
import copy
month = [31,28,31,30,31,30,31,31,30,31,30,31]

head1 = ['username', 'password', 'root', 'mailbox']
head2 = ['REPORT_NUM', 'EVENT_PROPERTY_NAME', 'EVENT_TYPE_ID', 'EVENT_TYPE_NAME', 'EVENT_SRC_NAME',
         'DISTRICT_ID', 'INTIME_ARCHIVE_NUM', 'SUB_TYPE_ID', 'DISTRICT_NAME', 'COMMUNITY_ID', 'REC_ID',
         'STREET_ID', 'OVERTIME_ARCHIVE_NUM', 'OPERATE_NUM', 'DISPOSE_UNIT_ID', 'STREET_NAME', 'CREATE_TIME',
         'EVENT_SRC_ID', 'INTIME_TO_ARCHIVE_NUM', 'SUB_TYPE_NAME',
         'EVENT_PROPERTY_ID', 'OCCUR_PLACE', 'COMMUNITY_NAME', 'DISPOSE_UNIT_NAME',
         'MAIN_TYPE_NAME', 'MAIN_TYPE_ID']
# sql = connect_sql.Sql('project_data')
# sql_1 = connect_sql.Sql('user_info')
#df = pd.read_csv('C:/Users/1/Desktop/user.csv')
# df = sql.read_database('project_data',head2)
# All_user = sql_1.read_database('user_info',head1)

#各街道民生情况
def STREET_MAIN_TYPE(df,date):
    #街道：石井，坪山，马峦，龙田，坑梓，碧岭
    event = []
    event_num = 0
    data_num = len(df)  # 数据库数据数量
    begin_time = datetime(date['time1']['year'], date['time1']['month'], date['time1']['day'])  # 开始时间
    if (month[date['time2']['month'] - 1] <= date['time2']['day']):
        end_time = datetime(date['time2']['year'], date['time2']['month'] + 1, 1)  # 结束时间
    else:
        end_time = datetime(date['time2']['year'], date['time2']['month'], date['time2']['day'] + 1)  # 结束时间
    for i in range(data_num):
        time = parse(df['CREATE_TIME'][i])  #当前数据时间
        if (begin_time <= time <= end_time):
            if(df['MAIN_TYPE_NAME'][i] not in event):
                event.append(df['MAIN_TYPE_NAME'][i])
                event_num+=1
        else:
            continue

    '''json = {'event_num':str(event_num),'event_name':event,
            '石井街道': {}, '坪山街道': {}, '马峦街道': {}, '龙田街道': {}, '坑梓街道': {}, '碧岭街道': {}}

    for i in range(event_num):
        json['石井街道'][event[i]] = 0
        json['坪山街道'][event[i]] = 0
        json['马峦街道'][event[i]] = 0
        json['龙田街道'][event[i]] = 0
        json['坑梓街道'][event[i]] = 0
        json['碧岭街道'][event[i]] = 0

    for i in range(data_num):
        time = parse(df['CREATE_TIME'][i])  #当前数据时间
        if (begin_time <= time <= end_time):
            if(df['STREET_NAME'][i] == '石井街道'):
                json['石井街道'][df['MAIN_TYPE_NAME'][i]]+=1
            elif (df['STREET_NAME'][i] == '坪山街道'):
                json['坪山街道'][df['MAIN_TYPE_NAME'][i]] += 1
            elif (df['STREET_NAME'][i] == '马峦街道'):
                json['马峦街道'][df['MAIN_TYPE_NAME'][i]] += 1
            elif (df['STREET_NAME'][i] == '龙田街道'):
                json['龙田街道'][df['MAIN_TYPE_NAME'][i]] += 1
            elif (df['STREET_NAME'][i] == '坑梓街道'):
                json['坑梓街道'][df['MAIN_TYPE_NAME'][i]] += 1
            else:
                json['碧岭街道'][df['MAIN_TYPE_NAME'][i]] += 1
        else:
            continue

    for i in range(event_num):
        json['石井街道'][event[i]] = str(json['石井街道'][event[i]])
        json['坪山街道'][event[i]] = str(json['坪山街道'][event[i]])
        json['马峦街道'][event[i]] = str(json['马峦街道'][event[i]])
        json['龙田街道'][event[i]] = str(json['龙田街道'][event[i]])
        json['坑梓街道'][event[i]] = str(json['坑梓街道'][event[i]])
        json['碧岭街道'][event[i]] = str(json['碧岭街道'][event[i]])'''

    json = {'event_num':str(event_num),'event_name':event}
    for i in range(event_num):
        json[event[i]] = [0,0,0,0,0,0,0]

    for i in range(data_num):
        time = parse(df['CREATE_TIME'][i])  # 当前数据时间
        if (begin_time <= time <= end_time):
            if (df['STREET_NAME'][i] == '石井街道'):
                json[df['MAIN_TYPE_NAME'][i]][0] += 1
            elif (df['STREET_NAME'][i] == '坪山街道'):
                json[df['MAIN_TYPE_NAME'][i]][1] += 1
            elif (df['STREET_NAME'][i] == '马峦街道'):
                json[df['MAIN_TYPE_NAME'][i]][2] += 1
            elif (df['STREET_NAME'][i] == '龙田街道'):
                json[df['MAIN_TYPE_NAME'][i]][3] += 1
            elif (df['STREET_NAME'][i] == '坑梓街道'):
                json[df['MAIN_TYPE_NAME'][i]][4] += 1
            elif (df['STREET_NAME'][i] == '碧岭街道'):
                json[df['MAIN_TYPE_NAME'][i]][5] += 1
            else:
                json[df['MAIN_TYPE_NAME'][i]][6] += 1
        else:
            continue


    return json

#事件类型分析
def EVENT_PROPERTY(df,date):#date为接收的json格式的日期年月日，df为数据库
    json ={}
    #    "EVENT_PROPERTY"---事件性质：建议，投诉，感谢，咨询，求决,其他
    data_num = len(df)  #数据库数据数量
    #print(data_num)
    #print(df['CREATE_TIME'][0])
    Advise = 0
    Complaint = 0
    Appreciation = 0
    Consultation = 0
    Determination = 0
    Others = 0
    begin_time = datetime(date['time1']['year'], date['time1']['month'], date['time1']['day'])  # 开始时间
    if (month[date['time2']['month'] - 1] <= date['time2']['day']):
        end_time = datetime(date['time2']['year'], date['time2']['month'] + 1, 1)  # 结束时间
    else:
        end_time = datetime(date['time2']['year'], date['time2']['month'], date['time2']['day'] + 1)  # 结束时间
    for i in range(data_num):
        time = parse(df['CREATE_TIME'][i])  #当前数据时间
        #print(i,time)
        if(begin_time<=time<=end_time):
            # EVENT_PROPERTY
            if(df['EVENT_PROPERTY_NAME'][i] == '建议'):
                Advise +=1
            elif (df['EVENT_PROPERTY_NAME'][i] == '投诉'):
                Complaint+=1
            elif (df['EVENT_PROPERTY_NAME'][i] == '感谢'):
                Appreciation+=1
            elif (df['EVENT_PROPERTY_NAME'][i] == '咨询'):
                Consultation+=1
            elif (df['EVENT_PROPERTY_NAME'][i] == '求决'):
                Determination+=1
            else:
                Others += 1
        else:
            continue
    json['建议'] = Advise
    json['投诉'] = Complaint
    json['感谢'] = Appreciation
    json['咨询'] = Consultation
    json['求决'] = Determination
    json['其他'] = Others
    return json

#热点社区
def Hot_Community(df,date):
    json = {'竹坑社区': 0, '秀新社区': 0, '田心社区': 0, '汤坑社区': 0, '石井社区': 0, '沙田社区': 0,
            '沙坣社区': 0, '沙湖社区': 0, '坪山社区': 0, '坪环社区': 0, '南布社区': 0, '马峦社区': 0,
            '龙田社区': 0, '六联社区': 0, '六和社区': 0, '老坑社区': 0, '坑梓社区': 0, '金沙社区': 0,
            '金龟社区': 0, '江岭社区': 0, '和平社区': 0, '碧岭社区': 0, '田头社区': 0,'-':0}
    json_new = {'data': []}
    begin_time = datetime(date['time1']['year'], date['time1']['month'], date['time1']['day'])  # 开始时间
    if (month[date['time2']['month'] - 1] <= date['time2']['day']):
        end_time = datetime(date['time2']['year'], date['time2']['month'] + 1, 1)  # 结束时间
    else:
        end_time = datetime(date['time2']['year'], date['time2']['month'], date['time2']['day'] + 1)  # 结束时间
    data_num = len(df)
    for i in range(data_num):
        time = parse(df['CREATE_TIME'][i])  # 当前数据时间
        if (begin_time <= time <= end_time):
            json[df['COMMUNITY_NAME'][i]] += 1
        else:
            continue
    json_new['data'].append({'name': "竹坑社区", 'value': json['竹坑社区']})
    json_new['data'].append({'name': "秀新社区", 'value': json['秀新社区']})
    json_new['data'].append({'name': "田心社区", 'value': json['田心社区']})
    json_new['data'].append({'name': "汤坑社区", 'value': json['汤坑社区']})
    json_new['data'].append({'name': "石井社区", 'value': json['石井社区']})
    json_new['data'].append({'name': "沙田社区", 'value': json['沙田社区']})
    json_new['data'].append({'name': "沙坣社区", 'value': json['沙坣社区']})
    json_new['data'].append({'name': "沙湖社区", 'value': json['沙湖社区']})
    json_new['data'].append({'name': "坪山社区", 'value': json['坪山社区']})
    json_new['data'].append({'name': "坪环社区", 'value': json['坪环社区']})
    json_new['data'].append({'name': "南布社区", 'value': json['南布社区']})
    json_new['data'].append({'name': "马峦社区", 'value': json['马峦社区']})
    json_new['data'].append({'name': "龙田社区", 'value': json['龙田社区']})
    json_new['data'].append({'name': "六联社区", 'value': json['六联社区']})
    json_new['data'].append({'name': "六和社区", 'value': json['六和社区']})
    json_new['data'].append({'name': "老坑社区", 'value': json['老坑社区']})
    json_new['data'].append({'name': "坑梓社区", 'value': json['坑梓社区']})
    json_new['data'].append({'name': "金沙社区", 'value': json['金沙社区']})
    json_new['data'].append({'name': "金龟社区", 'value': json['金龟社区']})
    json_new['data'].append({'name': "江岭社区", 'value': json['江岭社区']})
    json_new['data'].append({'name': "和平社区", 'value': json['和平社区']})
    json_new['data'].append({'name': "碧岭社区", 'value': json['碧岭社区']})
    json_new['data'].append({'name': "田头社区", 'value': json['田头社区']})
    return json_new

'''
def Handling_problems(df,date):
    type = []
    type_num = 0
    begin_time = datetime(date['time1']['year'], date['time1']['month'], date['time1']['day'])  # 开始时间
    end_time = datetime(date['time2']['year'], date['time2']['month'], date['time2']['day'] + 1)  # 结束时间
    data_num = len(df)
    for i in range(data_num):
        time = parse(df['CREATE_TIME'][i])  # 当前数据时间
        if (begin_time <= time <= end_time):
            if (df['EVENT_TYPE_NAME'][i] not in type):
                type.append(df['EVENT_TYPE_NAME'][i])
                type_num += 1
        else:
            continue

    json = { 'all_type':['处置中','超期结办','按期结办'] ,
             'inner_type':[{'value':0,'name':'处置中'},{'value':0,'name':'超期结办'},{'value':0,'name':'按期结办'}],
             'outer_type':[]
    }

    for i in range(type_num):
        #if type[i] not in json['all_type']:
        json['all_type'].append(type[i])
        outer = {'value':0,'name':type[i]}
        json['outer_type'].append(outer)

    for i in range(data_num):
        time = parse(df['CREATE_TIME'][i])  # 当前数据时间
        if (begin_time <= time <= end_time):
            if(df['OVERTIME_ARCHIVE_NUM'][i] == 1):
                json['inner_type'][1]['value'] += 1
            elif (df['INTIME_TO_ARCHIVE_NUM'][i] == 1):
                json['inner_type'][0]['value'] += 1
            else :
                json['inner_type'][2]['value'] += 1
            for j in range(type_num):
                if(df['EVENT_TYPE_NAME'][i] == type[j]):
                    json['outer_type'][j]['value']+=1
                else:
                    continue
        else:
            continue

    return json'''

def Handling_problems(df,date):
    type = []
    type1 = []  #超期结办
    type2 = []  #结办中
    type3 = []  #按期结办
    type_num = 0
    type1_num = 0
    type2_num = 0
    type3_num = 0
    begin_time = datetime(date['time1']['year'], date['time1']['month'], date['time1']['day'])  # 开始时间
    if (month[date['time2']['month'] - 1] <= date['time2']['day']):
        end_time = datetime(date['time2']['year'], date['time2']['month'] + 1, 1)  # 结束时间
    else:
        end_time = datetime(date['time2']['year'], date['time2']['month'], date['time2']['day'] + 1)  # 结束时间
    data_num = len(df)
    for i in range(data_num):
        time = parse(df['CREATE_TIME'][i])  # 当前数据时间
        if (begin_time <= time <= end_time):
            if (df['OVERTIME_ARCHIVE_NUM'][i] == 1):
                if (df['EVENT_TYPE_NAME'][i] not in type1):
                    type1.append(df['EVENT_TYPE_NAME'][i])
                    type1_num += 1
            elif (df['INTIME_TO_ARCHIVE_NUM'][i] == 1):
                if (df['EVENT_TYPE_NAME'][i] not in type2):
                    type2.append(df['EVENT_TYPE_NAME'][i])
                    type1_num += 1
            else:
                if (df['EVENT_TYPE_NAME'][i] not in type3):
                    type3.append(df['EVENT_TYPE_NAME'][i])
                    type3_num += 1
            if (df['EVENT_TYPE_NAME'][i] not in type):
                type.append(df['EVENT_TYPE_NAME'][i])
                type_num += 1
        else:
            continue

    json = { 'all_type':['处置中','超期结办','按期结办'] ,
             'inner_type':[{'value':0,'name':'处置中'},{'value':0,'name':'超期结办'},{'value':0,'name':'按期结办'}],
             'outer_type':[],
             '处置中':[],
             '超期结办':[],
             '按期结办':[]
    }

    for i in range(type_num):
        #if type[i] not in json['all_type']:
        json['all_type'].append(type[i])
        outer = {'value':0,'name':type[i]}
        json['outer_type'].append(outer)

    for i in range(type1_num):
        #if type[i] not in json['all_type']:
        outer = {'value':0,'name':type1[i]}
        json['超期结办'].append(outer)

    for i in range(type2_num):
        #if type[i] not in json['all_type']:
        outer = {'value':0,'name':type2[i]}
        json['处置中'].append(outer)

    for i in range(type3_num):
        #if type[i] not in json['all_type']:
        outer = {'value':0,'name':type3[i]}
        json['按期结办'].append(outer)

    for i in range(data_num):
        time = parse(df['CREATE_TIME'][i])  # 当前数据时间
        if (begin_time <= time <= end_time):
            if(df['OVERTIME_ARCHIVE_NUM'][i] == 1):
                json['inner_type'][1]['value'] += 1
            elif (df['INTIME_TO_ARCHIVE_NUM'][i] == 1):
                json['inner_type'][0]['value'] += 1
            else :
                json['inner_type'][2]['value'] += 1
            for j in range(type_num):
                if(df['EVENT_TYPE_NAME'][i] == type[j]):
                    json['outer_type'][j]['value']+=1
                else:
                    continue
            for j in range(type1_num):
                if(df['EVENT_TYPE_NAME'][i] == type1[j]):
                    json['超期结办'][j]['value']+=1
                else:
                    continue
            for j in range(type2_num):
                if(df['EVENT_TYPE_NAME'][i] == type2[j]):
                    json['处置中'][j]['value']+=1
                else:
                    continue
            for j in range(type3_num):
                if(df['EVENT_TYPE_NAME'][i] == type3[j]):
                    json['按期结办'][j]['value']+=1
                else:
                    continue
        else:
            continue
    return json

def get_realtime_data(date,df):
    realtime_data = []
    begin_time = datetime(date['time1']['year'], date['time1']['month'], date['time1']['day'])  # 开始时间
    if (month[date['time2']['month'] - 1] <= date['time2']['day']):
        end_time = datetime(date['time2']['year'], date['time2']['month'] + 1, 1)  # 结束时间
    else:
        end_time = datetime(date['time2']['year'], date['time2']['month'], date['time2']['day'] + 1)  # 结束时间
    data_num = len(df)
    for i in range(data_num):
        time = parse(df['CREATE_TIME'][i])  # 当前数据时间
        if (begin_time <= time <= end_time):
            a = {'CREATE_TIME':df['CREATE_TIME'][i],'STREET_NAME':df['STREET_NAME'][i],
                 'COMMUNITY_NAME':df['COMMUNITY_NAME'][i],'SUB_TYPE_NAME':df['SUB_TYPE_NAME'],
                 'DISPOSE_UNIT_NAME':df['DISPOSE_UNIT_NAME'][i],'EVENT_SRC_NAME':df['EVENT_SRC_NAME'][i],
                 'EVENT_PROPERTY_NAME':df['EVENT_PROPERTY_NAME'][i],'MAIN_TYPE_NAME':df['MAIN_TYPE_NAME'][i],
                 'EVENT_TYPE_NAME':df['EVENT_TYPE_NAME'][i]}
            realtime_data.append(a)
    return realtime_data


def effic_of_deptm(df, date):
    json = {"部门":["龙田","坑梓","马峦","石井","碧岭","坪山","其他"],"效率":[]}
    ltt = 0
    ptt = 0
    btt = 0
    mtt = 0
    stt = 0
    ktt = 0
    othertt = 0
    l = 0
    p = 0
    b = 0
    m = 0
    s = 0
    k = 0
    other = 0
    begin_time = datetime(date['time1']['year'], date['time1']['month'], date['time1']['day'])  # 开始时间
    if (month[date['time2']['month']-1] <= date['time2']['day']) :
        end_time = datetime(date['time2']['year'], date['time2']['month']+1, 1)  # 结束时间
    else:
        end_time = datetime(date['time2']['year'], date['time2']['month'], date['time2']['day'] + 1)  # 结束时间
    data_num = len(df)
    for i in range(data_num):
        time = parse(df['CREATE_TIME'][i])  # 当前数据时间
        if (begin_time <= time <= end_time):
            #print('kkkkkkkk',i)
            if ("龙田" in df['DISPOSE_UNIT_NAME'][i]):
                ltt = ltt+1
                if(df['INTIME_ARCHIVE_NUM'][i]  == 1):
                    l = l+1
            elif ("坑梓" in df['DISPOSE_UNIT_NAME'][i]):
                ktt = ktt+1
                if(df['INTIME_ARCHIVE_NUM'][i]  == 1):
                    k = k+1
            elif ("马峦" in df['DISPOSE_UNIT_NAME'][i]):
                mtt = mtt+1
                if(df['INTIME_ARCHIVE_NUM'][i]  == 1):
                    m = m+1
            elif ("碧岭" in df['DISPOSE_UNIT_NAME'][i]):
                btt = btt+1
                if(df['INTIME_ARCHIVE_NUM'][i]  == 1):
                    b = b+1
            elif ("坪山" in df['DISPOSE_UNIT_NAME'][i]):
                ptt = ptt+1
                if(df['INTIME_ARCHIVE_NUM'][i]  == 1):
                    p = p+1
            elif ("石井" in df['DISPOSE_UNIT_NAME'][i]):
                stt = stt+1
                if(df['INTIME_ARCHIVE_NUM'][i] == 1):
                    s = s+1
            else :
                othertt = othertt+1
                if (df['INTIME_ARCHIVE_NUM'][i] == 1):
                    other = other + 1
        else:
            continue
    if (ltt == 0):
        ltt+=1
    if (ktt == 0):
        ktt+=1
    if (mtt == 0):
        mtt+=1
    if (stt == 0):
        stt+=1
    if (btt == 0):
        btt+=1
    if (ptt == 0):
        ptt+=1
    if (othertt == 0):
        othertt+=1
    #print(l,k,m,s,b,p,other)
    #print(ltt,ktt,mtt,stt,btt,ptt,othertt)
    json['效率'].append(l/ltt * 100)
    json['效率'].append(k / ktt * 100)
    json['效率'].append(m / mtt * 100)
    json['效率'].append(s / stt * 100)
    json['效率'].append(b / btt * 100)
    json['效率'].append(p / ptt * 100)
    json['效率'].append(other / othertt * 100)
    return json


def judge_prior(data):
    ret = 1
    if (data['SUB_TYPE_NAME'] == '失职渎职'):
        ret = 2
    if data['SUB_TYPE_NAME'] == '违反工作纪律':
        ret = 2
    if data['SUB_TYPE_NAME'] == '招生违法行为':
        ret = 2
    if data['SUB_TYPE_NAME'] == '经营者欠薪后逃逸、隐匿，或因欠薪被劳动者投诉':
        ret = 2
    if data['SUB_TYPE_NAME'] == '道路塌陷、盖板坍塌':
        ret = 2
    if data['SUB_TYPE_NAME'] == '市政公园设施隐患':
        ret = 2
    if data['MAIN_TYPE_NAME'] == '医患纠纷':
        ret = 2
    if data['MAIN_TYPE_NAME'] == '无证无照经营':
        ret = 2
    if data['MAIN_TYPE_NAME'] == '其他市容违法行为或影响市容事件':
        ret = 2
    if data['MAIN_TYPE_NAME'] == '宣传广告违法行为':
        ret = 2
    if data['EVENT_TYPE_NAME'] == '治安维稳':
        ret = 2
    if data['EVENT_TYPE_NAME'] == '环保水务':
        ret = 2
    if data['MAIN_TYPE_NAME'] == '违法建筑与用地行为':
        ret = 3
    if data['MAIN_TYPE_NAME'] == '违反计生政策':
        ret = 3
    if data['MAIN_TYPE_NAME'] == '食品安全':
        ret = 3
    if data['EVENT_TYPE_NAME'] == '安全隐患':
        ret = 4
    if data['SUB_TYPE_NAME'] == '滥用职权':
        ret = 4
    if data['MAIN_TYPE_NAME'] == '医疗机构违规经营':
        ret = 4
    if data['MAIN_TYPE_NAME'] == '市场垄断':
        ret = 4
    return ret

#事件优先级分4种 ，异常事件为4，红橙黄对应321
'''Abnormal = ['安全隐患'(问题类型),'滥用职权',(小类名称),'医疗机构违规经营'(大类名称),'市场垄断'(大类名称)]
    red = ['违法建筑与用地行为'(大类名称),'违反计生政策'(大类名称),'食品安全'(大类名称),]
    orange = ['失职渎职','违反工作纪律'(小类名称),'环保水务'(问题类型),'招生违法行为'(小类名称),
              '医患纠纷'(大类名称),'经营者欠薪后逃逸、隐匿，或因欠薪被劳动者投诉'(小类名称),'道路塌陷、盖板坍塌'(小类名称)
              '无证无照经营'(大类名称),'其他市容违法行为或影响市容事件'(大类名称),'宣传广告违法行为'(大类名称),'市政公园设施隐患'(小类名称),'治安维稳'(问题类型)]
    yellow = ['others']'''

def Abnormal_event(data):
    ret_list = {}
    prior = 0
    if (data['EVENT_PROPERTY_NAME'] == '投诉'):
        prior = judge_prior(data)
        ret_list = {'等级':prior,'时间':data['CREATE_TIME'],'街道':data['STREET_NAME']	,
			'社区':data['COMMUNITY_NAME'],'来源':data['EVENT_SRC_NAME'],'问题':data['SUB_TYPE_NAME'],
			'类型':data['EVENT_PROPERTY_NAME'],'部门':data['DISPOSE_UNIT_NAME']}
    return ret_list

def ABE_sim(df,cnt):
    length = len(df)
    list = {'alert': []}
    if cnt < length:
        if(Abnormal_event(df.loc[cnt]) == {}):
            list = {}
        else:
            list['alert'].append(Abnormal_event(df.loc[cnt]))
    else:
        list = {}
    return list

def time_simulation(date,df,head):
    #df_new = copy.deepcopy(df)
    j = 0
    df_new = pd.DataFrame(columns=head)
    #df_new.columns = head
    data_num = len(df)  # 数据库数据数量
    begin_time = datetime(date['year'], date['month'], date['day'])  # 开始时间
    if (month[date['month'] - 1] <= date['day']):
        end_time = datetime(date['year'], date['month'] + 1, 1)  # 结束时间
    else:
        end_time = datetime(date['year'], date['month'], date['day'] + 1)  # 结束时间
    for i in range(data_num):

        time = parse(df['CREATE_TIME'][i])  # 当前数据时间
        if (begin_time <= time <= end_time):
            df_new.loc[j] = df.loc[i]
            #print(df.loc[i])
            #print(df_new.loc[j])
            j += 1
        else:

            #df_new = df_new.drop([i])
            pass
    return df_new

def deletedate(date,df):
    data_num = len(df)  # 数据库数据数量
    #print(data_num)
    begin_time = datetime(date['year'], date['month'], date['day'])  # 开始时间
    if (month[date['month'] - 1] <= date['day']):
        end_time = datetime(date['year'], date['month'] + 1, 1)  # 结束时间
    else:
        end_time = datetime(date['year'], date['month'], date['day'] + 1)  # 结束时间
    for i in range(data_num):
        time = parse(df['CREATE_TIME'][i])  # 当前数据时间
        if (begin_time <= time <= end_time):
            df = df.drop([i])
        else:
            continue
    #print(df)
    return df.reset_index(drop=True)

def df_time(count,df_new):
    df_t = df_new.iloc[0:count]
    return df_t




def User_Check(All_user,data): #data为接收的json格式的需要登陆的账户信息，ALL_user为用户信息库
    user = data["username"]
    password = data["password"]
    user_num =len(All_user)
    json = {}
    for i in range(user_num):
        if (str(user) == str(All_user['username'][i])):#账户，密码都设为字符串
            if(str(password)== str(All_user['password'][i])):
            #if check_password_hash(All_user['password'][i], password):
                json['answer'] = '0'
                return json #0表示账户密码匹配成功
            else:
                json['answer'] = '1'
                return json #1表示密码错误
        else:
            continue
    json['answer'] = '2'
    return json  #2表示用户不存在


date = {'order': 2, 'time1': {'year': 2018, 'month': 10, 'day': 16}, 'time2': {'year': 2018, 'month': 10, 'day': 30}}


#{username,password, change_mailbox}
def change_password(All_user, data, sql):#要更新数据库
    #print(All_user)
    list = []
    user = data["username"]
    password = data['password']
    root = data['root']
    #list.append((password,root,mail))
    user_num = len(All_user)
    #change_mailbox = data['change_mailbox']
    mailbox = data['mailbox']
    json = {}
    #if change_mailbox == 0:
    if mailbox == "":
        for i in range(user_num):
            if (str(user) == str(All_user['username'][i])):
                #if check_password_hash(All_user['password'][i], password):

                if (str(password) == str(All_user['password'][i])):
                    json['change_password'] = 0 #'表示与原密码一致，给出提示'

                    json['change_mailbox'] = 1
                    return json
                else:
                    #All_user['password'][i] = generate_password_hash(password)
                    mailbox = All_user['mailbox'][i]
                    list.append((password,root,mailbox,user))
                    json['change_password'] = 1
                    All_user['password'][i] = password
                    json['change_mailbox'] = 1
                    sql.update_database('user_info', list)
                    return json
    else:
        for i in range(user_num):
            if (str(user) == str(All_user['username'][i])):
                #if check_password_hash(All_user['password'][i], password):
                if (str(password) == str(All_user['password'][i])):
                    json['change_password'] = 0 #'表示与原密码一致，给出提示'
                else:
                    json['change_password'] = 1

                if (str(mailbox) == str(All_user['mailbox'][i])):
                    json['change_mailbox'] = 0
                else:
                    json['change_mailbox'] = 1
                if (json['change_password'] == 1 and json['change_mailbox'] == 1):
                    # All_user['password'][i] = generate_password_hash(password)
                    All_user['mailbox'][i] = mailbox
                    All_user['password'][i] = password
                    list.append((password, root, mailbox, user))
                    json['change_password'] = 1  # 修改成功
                    json['change_mailbox'] = 1
                    sql.update_database('user_info', list)
                return json


def judge_account(All_user, data):
    user = data['username']
    user_num = len(All_user)
    json = {}
    for i in range(user_num):
        if (str(user) == str(All_user['username'][i])):
            json['judge'] = 0
            return json

    json['judge'] = 1
    return json



def regist_account(All_user, data, sql):#要更新数据库
    list = []
    user = data['username']
    password = data['password']
    mailbox = data['mailbox']
    user_num = len(All_user)
    root = '0'
    json = {}
    for i in range(user_num):
        if (str(mailbox) == str(All_user['mailbox'][i])):
            json['regist'] = 0
            return json
    # tmp_df = pd.DataFrame()
    # tmp_df.columns = head1
    # tmp_df['username'] = user
    # tmp_df['passwor'] = password
    # tmp_df['root'] = root
    # tmp_df['mailbox'] = mailbox
    All_user.loc[user_num] = {'username':user, 'password':password, 'root':root, 'mailbox':mailbox}
    #print(All_user)
    json['regist'] = 1
    list.append((user,password,root,mailbox))
    sql.insert_database('user_info', list)
    return json


def find_password(All_user, data):
    mailbox = data['mailbox']
    user_num = len(All_user)
    json = {}
    for i in range(user_num):
        if (str(mailbox) == str(All_user['mailbox'][i])):
            # if check_password_hash(All_user['password'][i], password):
            json['find_password'] = All_user['password'][i]
            return json
    json['find_password'] = 0
    return json


def withdraw_account(All_user, data, sql):
    list = []
    username = data['username']
    user_num = len(All_user)
    #print(user_num)
    json = {}
    for i in range(user_num):
        if (str(username) == str(All_user['username'][i])):
            All_user.drop([i],inplace=True)
            json['withdraw'] = 1
            #print("ins", All_user)
            All_user.reset_index(drop=True, inplace=True)
            #print("ins!!!!!!", All_user.loc[1])
            list.append((username))
            sql.delete_database('user_info', list)
            return json

    json['withdraw'] = 0
    return json
def return_root(All_user,username):
    root = -1
    user_num = len(All_user)
    for i in range(user_num):
        if(str(username) == str(All_user['username'][i])):
            root = All_user['root'][i]
            return root
    return root