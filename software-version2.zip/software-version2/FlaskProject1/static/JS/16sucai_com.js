// JavaScript Document
var ii = 0;
var jj = 0;
var kk = 0;

function build_label(ele,jj,content,color){
	var get_label = document.getElementById(ele);
	get_label.innerHTML = al_ele[jj][content];
	get_label.style.color = color;
};
function H$(i) {return document.getElementById(i)}
function H$$(c, p) {return p.getElementsByTagName(c)}
var slider = function () {
	
	function init (o) {
		this.id = o.id;
		this.at = o.auto ? o.auto : 3;
		this.o = 0;
		this.pos();
	}
	init.prototype = {
		pos : function () {
			clearInterval(this.__b);
			this.o = 0;
			var el = H$(this.id), li = H$$('li', el), l = li.length;
			var _t = li[l-1].offsetHeight;
			var cl = li[l-1].cloneNode(true);
			cl.style.opacity = 0; cl.style.filter = 'alpha(opacity=0)';
			el.insertBefore(cl, el.firstChild);
			el.style.top = -_t + 'px';
			this.anim();

			// var imgsrc1 = document.getElementById('img01');
			// console.log(imgsrc1);
			// var imgsrc2 = document.getElementById('img02');
			var imgsrc1 = document.getElementsByClassName('imgtag')[0];
			var imgsrc2 = document.getElementsByClassName('imgtag')[1];
			function change_img(index){
				var imgsrc;
				switch(al_img[index]){
					case 1:imgsrc = "../static/Image/001.jpg";break;
					case 2:imgsrc = "../static/Image/002.jpg";break;
					case 3:imgsrc = "../static/Image/003.jpg";break;
					case 4:imgsrc = "../static/Image/004.gif";break;
					default:imgsrc = "../static/Image/001.jpg";break;
				}
				return imgsrc;
			}
			//console.log(al_img.length,'数组');
			if(ii%2 == 0) {
				//txt1.innerHTML = data[i];
				//get_la11.innerHTML = al_ele[jj]['时间'];
				//console.log(jj, 'jjjjjjjjjjjjj');
				if (jj < al_img.length) {
					imgsrc2.src = change_img(jj);
					build_label('la11', jj, '时间', '#808080');
					build_label('la12', jj, '街道', '#FF7D00');
					build_label('la13', jj, '社区', '#CCCC33');
					build_label('la14', jj, '来源', '#00FF00');
					build_label('la15', jj, '问题', '#FF0000');
					build_label('la16', jj, '类型', '#00FFFF');
					build_label('la17', jj, '部门', '#FF00FF');

					jj++;
				}
			}
			if(ii%2 == 1||kk == 0)
			{
				//get_la01.innerHTML = al_ele[jj]['时间'];
			if(jj < al_img.length) {
				imgsrc1.src = change_img(jj);
				//console.log(jj, 'oooooooooooooooooo');
				build_label('la01', jj, '时间', '#808080');
				build_label('la02', jj, '街道', '#FF7D00');
				build_label('la03', jj, '社区', '#FFFF00');
				build_label('la04', jj, '来源', '#00FF00');
				build_label('la05', jj, '问题', '#FF0000');
				build_label('la06', jj, '类型', '#00FFFF');
				build_label('la07', jj, '部门', '#FF00FF');

				jj++;
				kk = 1;
			}
			}
			ii+=1;
			//console.log(jj,'kkkkkkkkkkkkkkkkk');
			//console.log(al_img.length,'数组');
			if(jj >= al_img.length)
			{
				jj = 0;
			}

		},
		anim : function () {
			var _this = this;
			this.__a = setInterval(function(){_this.animH()}, 20);
		},
		animH : function () {
			var _t = parseInt(H$(this.id).style.top), _this = this;
			if (_t >= -1) {
				clearInterval(this.__a);
				H$(this.id).style.top = 0;
				var list = H$$('li',H$(this.id));
				H$(this.id).removeChild(list[list.length-1]);
				this.__c = setInterval(function(){_this.animO()}, 20);
				//this.auto();
			}else {
				var __t = Math.abs(_t) - Math.ceil(Math.abs(_t)*.07);
				H$(this.id).style.top = -__t + 'px';
			}
		},
		animO : function () {
			this.o += 2;
			if (this.o == 100) {
				clearInterval(this.__c);
				H$$('li',H$(this.id))[0].style.opacity = 1;
				H$$('li',H$(this.id))[0].style.filter = 'alpha(opacity=100)';
				this.auto();
			}else {
				H$$('li',H$(this.id))[0].style.opacity = this.o/100;
				H$$('li',H$(this.id))[0].style.filter = 'alpha(opacity='+this.o+')';
			}
		},
		auto : function () {
			var _this = this;
			this.__b = setInterval(function(){_this.pos()}, this.at*1000);
			
		}
	}
	return init;
}();

