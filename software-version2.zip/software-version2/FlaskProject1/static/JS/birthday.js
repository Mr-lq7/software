var start_date = {};
var end_date = {};
(function($){
	
$.extend({
ms_DatePicker: function (options) {
            var defaults = {
                YearSelector: "#sel_year",
                MonthSelector: "#sel_month",
                DaySelector: "#sel_day",
				HourSelector: "#sel_hour",
				YearSelector2: "#sel_year2",
				MonthSelector2: "#sel_month2",
				DaySelector2: "#sel_day2",
				HourSelector2: "#sel_hour2",
                FirstText: "--",
				FirstValuey:2018,
				FirstValuem:10,
				FirstValued:30,
				FirstValueh:0,
				FirstValueh2:24,
                FirstValue: 0
            };
            var opts = $.extend({}, defaults, options);
            var $YearSelector = $(opts.YearSelector);
            var $MonthSelector = $(opts.MonthSelector);
            var $DaySelector = $(opts.DaySelector);
			var $HourSelector = $(opts.HourSelector);
			var $YearSelector2 = $(opts.YearSelector2);
			var $MonthSelector2 = $(opts.MonthSelector2);
			var $DaySelector2 = $(opts.DaySelector2);
			var $HourSelector2 = $(opts.HourSelector2);
            var FirstText = opts.FirstText;
            var FirstValue = opts.FirstValue;
			var FirstValuey = opts.FirstValuey;
			var FirstValuem = opts.FirstValuem;
			var FirstValued = opts.FirstValued;
			var FirstValueh = opts.FirstValueh;
			var FirstValueh2 = opts.FirstValueh2;

            // 初始化
            var str = "<option value=\"" + FirstValue + "\">" + FirstText + "</option>";
			var stry = "<option value=\"" + FirstValuey + "\">" + FirstText + "</option>";
			var strm = "<option value=\"" + FirstValuem + "\">" + FirstText + "</option>";
			var strd = "<option value=\"" + FirstValued + "\">" + FirstText + "</option>";
			var strh = "<option value=\"" + FirstValueh + "\">" + FirstText + "</option>";
			var strh2 = "<option value=\"" + FirstValueh2 + "\">" + FirstText + "</option>";
            $YearSelector.html(stry);
            $MonthSelector.html(strm);
            $DaySelector.html(strd);
			$HourSelector.html(strh);
			$YearSelector2.html(stry);
			$MonthSelector2.html(strm);
			$DaySelector2.html(strd);
			$HourSelector2.html(strh2);
			start_date['Year'] = 2018;
			start_date['Month'] = 10;
			start_date['Day'] = 30;
			start_date['Hour'] = 0;
			end_date['Year'] = 2018;
			end_date['Month'] = 10;
			end_date['Day'] = 30;
			end_date['Hour'] = 24;
            // 年份列表
			function years(YS){
				var yearNow = new Date().getFullYear();
				var yearSel = YS.attr("rel");
				for (var i = yearNow; i >= 2010; i--) {
					var sed = yearSel==i?"selected":"";
					var yearStr = "<option value=\"" + i + "\" " + sed+">" + i + "</option>";
				    YS.append(yearStr);
				}
			};
			years($YearSelector);
			years($YearSelector2);
            

            // 月份列表
			function months(MS){
				var monthSel = MS.attr("rel");
				for (var i = 1; i <= 12; i++) {
					var sed = monthSel==i?"selected":"";
				    var monthStr = "<option value=\"" + i + "\" "+sed+">" + i + "</option>";
				    MS.append(monthStr);
				}
			}
			months($MonthSelector);
			months($MonthSelector2);

            // 日列表(仅当选择了年月)
            function BuildDay(YS, MS, DS) {
                if (YS.val() == 0 || MS.val() == 0) {
                    // 未选择年份或者月份
                    DS.html(str);
                } else {
                    DS.html(str);
                    var year = parseInt(YS.val());
                    var month = parseInt(MS.val());
                    var dayCount = 0;
                    switch (month) {
                        case 1:
                        case 3:
                        case 5:
                        case 7:
                        case 8:
                        case 10:
                        case 12:
                            dayCount = 31;
                            break;
                        case 4:
                        case 6:
                        case 9:
                        case 11:
                            dayCount = 30;
                            break;
                        case 2:
                            dayCount = 28;
                            if ((year % 4 == 0) && (year % 100 != 0) || (year % 400 == 0)) {
                                dayCount = 29;
                            }
                            break;
                        default:
                            break;
                    }
					
					var daySel = DS.attr("rel");
                    for (var i = 1; i <= dayCount; i++) {
						var sed = daySel==i?"selected":"";
						var dayStr = "<option value=\"" + i + "\" "+sed+">" + i + "</option>";
                        DS.append(dayStr);
                    }
                }
            }
			
			function hours(HS){
				var hourSel = HS.attr("rel");
				for (var i = 1; i <= 24; i++) {
					var sed = hourSel==i?"selected":"";
				    var hourStr = "<option value=\"" + i + "\" "+sed+">" + i + "</option>";
				    HS.append(hourStr);
				}
			}
			hours($HourSelector);
			hours($HourSelector2);
			
            $MonthSelector.change(function () {
                BuildDay($YearSelector, $MonthSelector, $DaySelector);
				console.log($("#sel_month option:selected").val());
				start_date['Month'] = $("#sel_month option:selected").val();
            });
            $YearSelector.change(function () {
                BuildDay($YearSelector, $MonthSelector, $DaySelector);
				console.log($("#sel_year option:selected").val());
				start_date['Year'] = $("#sel_year option:selected").val();
            });
			$DaySelector.change(function () {
				console.log($("#sel_day option:selected").val());
				start_date['Day'] = $("#sel_day option:selected").val();
			});
			$HourSelector.change(function () {
				console.log($("#sel_hour option:selected").val());
				start_date['Hour'] = $("#sel_hour option:selected").val();
			});
			
			$MonthSelector2.change(function () {
			    BuildDay($YearSelector2, $MonthSelector2, $DaySelector2);
				console.log($("#sel_month2 option:selected").val());
				end_date['Month'] = $("#sel_month2 option:selected").val();
			});
			$YearSelector2.change(function () {
			    BuildDay($YearSelector2, $MonthSelector2, $DaySelector2);
				console.log($("#sel_year2 option:selected").val());
				end_date['Year'] = $("#sel_year2 option:selected").val();
			});
			$DaySelector2.change(function () {
				console.log($("#sel_day2 option:selected").val());
				end_date['Day'] = $("#sel_day2 option:selected").val();
			});
			$HourSelector2.change(function () {
				console.log($("#sel_hour2 option:selected").val());
				end_date['Hour'] = $("#sel_hour2 option:selected").val();
			});
			
			if($DaySelector.attr("rel")!=""){
				BuildDay($YearSelector, $MonthSelector, $DaySelector);
			}
			if($DaySelector2.attr("rel")!=""){
				BuildDay($YearSelector2, $MonthSelector2, $DaySelector2);
			}
			
        } // End ms_DatePicker
});
	
})(jQuery);
