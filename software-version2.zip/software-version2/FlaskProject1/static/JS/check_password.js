var hostnametmp="";

var flagb = 0;

exchangemassage={"username":"","password":"","mailbox":""};
function check(password){
	flag = 0;
	O_color="#eeeeee";
	L_color="#FF0000";
	M_color="#FF9900";
	H_color="#33CC00";
	
	var check_password = document.getElementById("strong");
	//var o_password = document.getElementById("name1").value;
	
	 var reg_s = /^[0-9]{6,16}$|^[a-zA-Z]{5,16}$/;
	 var reg_o = /^[A-Za-z0-9]{5,16}$/;
	 var reg_h = /^(?=.*[a-zA-Z])(?=.*\d)(?=.*[~!@#$%^&*()_+`\-={}:";'<>?,.\/]).{5,16}$/;
	
	if (reg_s.test(password)) {
	check_password.innerHTML = "密码等级'较弱'";
	}else if (reg_o.test(password)) {
	check_password.innerHTML = "密码等级'中等'";
	check_password.style.color = M_color;
	}else if (reg_h.test(password)) {
	check_password.innerHTML = "密码等级'较强'";
	check_password.style.color = H_color;
	flag = 1;
	}
	
	if(password.length < 5){
		check_password.innerHTML = "密码太短";
		check_password.style.color = L_color;
	}else if(password.length > 16){
		check_password.innerHTML = "密码太长";
		check_password.style.color = L_color;
	}

	// if(o_password == password)
	// {
	// 	check_password.innerHTML = "与原密码相同";
	// 	check_password.style.color = L_color;
	// 	flag = 0;
	// }
		
}

function check_same(password){
	flags = 0;
	var password1 = document.getElementById("name2").value;
	var check_ifsame = document.getElementById("same");
	if(password1 != password)
	{
		check_ifsame.innerHTML = "输入密码不相同";
		check_ifsame.style.color = L_color;
		flags = 0;
	}else{
		check_ifsame.innerHTML = "";
		flags = 1;
	}
	
}

function check_email(password) {
	flagb = 0;
	var e_reg = /^([a-zA-Z]|[0-9])(\w|\-)+@[a-zA-Z0-9]+\.([a-zA-Z]{2,4})$/;

	if(e_reg.test(password) == false) {
		flagb = 0;
	}else {
		flagb = 1;
	}
}