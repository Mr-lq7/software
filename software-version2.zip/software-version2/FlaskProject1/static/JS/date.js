lay('#version').html('-v'+ laydate.v);
//限定可选日期
laydate.render({
	elem: '#test3'
	,type:'month'
	,btns: ['confirm']
	,value: '2018-10' 
	,max: '2018-10-30'
	,theme: 'molv'
	,done: function(value, date){
		getday3=dateget(date);
		//console.log(getday3);
        DisplayStatus_charts2();
	}
	});
laydate.render({
		elem: '#test2'
		,range: true
		,btns: ['confirm']
		,value: '2018-10-30 - 2018-10-30'
		,max: '2018-10-30'
		,theme: 'molv'
		,done: function(value, date, endDate){
			var day={};
			var day_end={};
			day["year"]=date.year;
			day["month"]=date.month;
			day["day"]=date.date;
			inputDatetmp["time1"]=day; //得到日期时间对象：{year: 2018, month: 10, date: 30}
			day_end["year"]=endDate.year;
			day_end["month"]=endDate.month;
			day_end["day"]=endDate.date;
			inputDatetmp["time2"]=day_end; //得到日期时间对象：{year: 2018, month: 10, date: 30}
			getday2=inputDatetmp;
			console.log(getday2);
			DisplayStatus_charts1();
		}
});
laydate.render({
		elem: '#test6'
		,range: true
		,btns: ['confirm']
		,value: '2018-10-30 - 2018-10-30'
		,max: '2018-10-30'
		,theme: 'molv'
		,done: function(value, date, endDate){
			var day={};
			var day_end={};
			day["year"]=date.year;
			day["month"]=date.month;
			day["day"]=date.date;
			inputDatetmp["time1"]=day; //得到日期时间对象：{year: 2018, month: 10, date: 30}
			day_end["year"]=endDate.year;
			day_end["month"]=endDate.month;
			day_end["day"]=endDate.date;
			inputDatetmp["time2"]=day_end; //得到日期时间对象：{year: 2018, month: 10, date: 30}
			getday6=inputDatetmp;
			//console.log(getday6);
			efficiency_charts();
		}
});
laydate.render({
  elem: '#test4'
  ,type:'month'
  ,btns: ['confirm']
  ,value: '2018-10' 
  ,max: '2018-10-30'
  ,theme: 'molv'
  ,done: function(value, date){
  	getday4=dateget(date);
  	//console.log(getday4);
  	DisplayStatus_charts3();
  }
});
$Date = laydate;
initDateForm();
function timetoday(){
	var secondchartdivshow = document.getElementById("secondcharts");
	var thridchartdivshow = document.getElementById("thirdcharts");
    if(secondchartdivshow.style.display == "block"){
		getday3={"time1":{year: 2018, month: 10, day: 30},"time2":{year: 2018, month: 10, day: 30}};
		//console.log(getday3);
		DisplayStatus_charts2();
	}else if(thridchartdivshow.style.display ==  "block"){
		getday4={"time1":{year: 2018, month: 10, day: 30},"time2":{year: 2018, month: 10, day: 30}};
		//console.log(getday4);
		DisplayStatus_charts3();
	}
}
function isNull(s) {
	if (s == null || typeof (s) == "undefined" || s == "") return true;
	return false;
}
function quarter(getday){
	var day={};
	var day_end={};
	switch(getday.month){
		case 1:
			day["year"]=getday.year;
			day["month"]=1;
			day["day"]=1;
			day_end["year"]=getday.year;
			day_end["month"]=3;
			day_end["day"]=31;
			inputDatetmp["time1"]=day;
			inputDatetmp["time2"]=day_end;
			return inputDatetmp
			break;
		case 2:
			day["year"]=getday.year;
			day["month"]=4;
			day["day"]=1;
			day_end["year"]=getday.year;
			day_end["month"]=6;
			day_end["day"]=30;
			inputDatetmp["time1"]=day;
			inputDatetmp["time2"]=day_end;
			return inputDatetmp
			break;
		case 3:
			day["year"]=getday.year;
			day["month"]=7;
			day["day"]=1;
			day_end["year"]=getday.year;
			day_end["month"]=9;
			day_end["day"]=30;
			inputDatetmp["time1"]=day;
			inputDatetmp["time2"]=day_end;
			return inputDatetmp
			break;
		case 4:
		    day["year"]=getday.year;
		    day["month"]=10;
		    day["day"]=1;
		    day_end["year"]=getday.year;
		    day_end["month"]=12;
		    day_end["day"]=31;
		    inputDatetmp["time1"]=day;
		    inputDatetmp["time2"]=day_end;
		    return inputDatetmp
		    break;
	}
}
function dateget(getday){
	var day={};
	var day_end={};
	switch (getday.month) {
	    case 1:
	    case 2:
	    case 3:
	    case 4:
	    case 5:
	    case 6:
	    case 7:
		case 8:
		case 9:
		case 11:
			day["year"]=getday.year;
			day["month"]=getday.month;
			day["day"]=1;
			day_end["year"]=getday.year;
			day_end["month"]=getday.month+1;
			day_end["day"]=1;
			inputDatetmp["time1"]=day;
			inputDatetmp["time2"]=day_end;
			return inputDatetmp
			break;
		case 10:
			if(getday.year==2018){
				day["year"]=getday.year;
				day["month"]=getday.month;
				day["day"]=1;
				day_end["year"]=getday.year;
				day_end["month"]=getday.month;
				day_end["day"]=30;
				inputDatetmp["time1"]=day;
				inputDatetmp["time2"]=day_end;
				return inputDatetmp
			}else{
				day["year"]=getday.year;
			day["month"]=getday.month;
			day["day"]=1;
			day_end["year"]=getday.year;
			day_end["month"]=getday.month+1;
			day_end["day"]=1;
			inputDatetmp["time1"]=day;
			inputDatetmp["time2"]=day_end;
			return inputDatetmp
			}
			break;
		case 12:
			day["year"]=getday.year;
			day["month"]=getday.month;
			day["day"]=1;
			day_end["year"]=getday.year+1;
			day_end["month"]=1;
			day_end["day"]=1;
			inputDatetmp["time1"]=day;
			inputDatetmp["time2"]=day_end;
			return inputDatetmp
			break;
	} 
}
function renderSeasonDate(ohd) {
            var ele = $(ohd);
            $Date.render({
                elem: ohd,
                type: 'month',
                format: 'yyyy年M季度',
				value: '2018年3季度',
				max: "2018-3-31",
                btns: [ 'confirm'],
                ready: function (value, date, endDate) {
                    var hd = $("#layui-laydate" + ele.attr("lay-key"));
                    if (hd.length > 0) {
                        hd.click(function () {
                            ren($(this));
                        });
                    }
                    ren(hd);
                },
                done: function (value, date) {
					getday5=quarter(date);
					//console.log(getday5);
                    DisplayStatus_charts4();
                }
            });
            var ren = function (thiz) {
                var mls = thiz.find(".laydate-month-list");
                mls.each(function (i, e) {
                    $(this).find("li").each(function (inx, ele) {
                        var cx = ele.innerHTML;
                        if (inx < 4) {
                            ele.innerHTML = cx.replace(/月/g, "季度");
                        } else {
                            ele.style.display = "none";
                        }
                    });
                });
            }
        }

function initDateForm(sgl, form) {
            if (isNull(form)) form = $(document.body);
            var ltm = function (tar, tars, tva) {
                tars.each(function () {
                    $(this).removeAttr("lay-key");
                    this.outerHTML = this.outerHTML;
                });
                tars = form.find(".dateTarget" + tar);
                tars.each(function () {
                    var ele = $(this);
					if ("s" == tva) {
                        ele.attr("startDate", "");
                        ele.attr("endDate", "");
						renderSeasonDate(this);
                    } else if ("m" == tva) {
                        $Date.render({
                            elem: this
                            ,type:'month'
                            ,btns: ['confirm']
                            ,value: '2018-10' 
                            ,max: '2018-10-30'
                            ,theme: 'molv'
                            ,done: function(value, date){
                            	getday5=dateget(date);
                            	//console.log(getday5);
                            	DisplayStatus_charts4();
                            }
                        });
                    } else if ("d" == tva) {
                        ele.attr("startDate", "");
                        ele.attr("endDate", "");
                        $Date.render({
                            elem: this
                            ,range: true
                            ,btns: ['confirm']
                            ,value: '2018-10-30 - 2018-10-30'
                            ,max: '2018-10-30'
                            ,theme: 'molv'
                            ,done: function(value, date, endDate){
                            	var day={};
                            	var day_end={};
                            	day["year"]=date.year;
                            	day["month"]=date.month;
                            	day["day"]=date.date;
                            	inputDatetmp["time1"]=day; //得到日期时间对象：{year: 2018, month: 10, date: 30}
                            	day_end["year"]=endDate.year;
                            	day_end["month"]=endDate.month;
                            	day_end["day"]=endDate.date;
                            	inputDatetmp["time2"]=day_end; //得到日期时间对象：{year: 2018, month: 10, date: 30}
                            	getday5=inputDatetmp;
                            	//console.log(getday5);
                            	DisplayStatus_charts4();
                            }
                        });
                    }
                });
            }
            var sels = form.find(".dateSelector");
            sels.each(function (i, e) {
                var ths = this;
                var thiz = $(e);
                var tar = thiz.attr("date-target");
                thiz.next().find("dd").click(function () {
                    var tva = thiz.val();
                    var tars = form.find(".dateTarget" + tar);
                    ltm(tar, tars, tva);
                });
                thiz.change(function () {
                    var tva = $(this).val();
                    var tars = form.find(".dateTarget" + tar);
                    ltm(tar, tars, tva);
                });
                var tars = form.find(".dateTarget" + tar);
                ltm(tar, tars, thiz.val());
            });
        }
