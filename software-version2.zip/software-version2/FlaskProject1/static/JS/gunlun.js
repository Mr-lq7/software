// JavaScript Document

function build_label2(ele,jj,content,color){
	var get_label2 = document.getElementById(ele);
	get_label2.innerHTML = al_ele2[jj][content];
	get_label2.style.color = color;
};
var ele = document.createElement('p');

//function build_text(index,txt1,txt2,txt4,txt6,txt8,txt9,txt11)
function build_text(index,tag)
{
	var la1 = document.createElement('label');
	la1.id = 'newla' + tag + '1';
	//la1.innerHTML = txt1;
	document.getElementById(index).appendChild(la1);
	
	var la2 = document.createElement('label');
	la2.id = 'newla' + tag + '2';
	//la2.innerHTML = txt2;
	document.getElementById(index).appendChild(la2);
	
	var la3 = document.createElement('label');
	la3.innerHTML = '的';
	document.getElementById(index).appendChild(la3);
	
	var la4 = document.createElement('label');
	la4.id = 'newla' + + tag + '3';
	//la4.innerHTML = txt4;
	document.getElementById(index).appendChild(la4);
	
	var la5 = document.createElement('label');
	la5.innerHTML = '从';
	document.getElementById(index).appendChild(la5);
	
	var la6 = document.createElement('label');
	la6.id = 'newla' + + tag + '4';
	//la6.innerHTML = txt6;
	document.getElementById(index).appendChild(la6);
	
	var la7 = document.createElement('label');
	la7.innerHTML = '接到';
	document.getElementById(index).appendChild(la7);
	
	var la8 = document.createElement('label');
	la8.id = 'newla' + + tag + '5';
	//la8.innerHTML = txt8;
	document.getElementById(index).appendChild(la8);
	
	var la9 = document.createElement('label');
	la9.id = 'newla' + + tag + '6';
	//la9.innerHTML = txt9;
	document.getElementById(index).appendChild(la9);
	
	var la10 = document.createElement('label');
	la10.innerHTML = ',请';
	document.getElementById(index).appendChild(la10);
	
	var la11 = document.createElement('label');
	la11.id = 'newla' + + tag + '7';
	//la11.innerHTML = txt11;
	document.getElementById(index).appendChild(la11);
	
	var la12 = document.createElement('label');
	la12.innerHTML = '尽快处理!';
	document.getElementById(index).appendChild(la12);
	
	var la13 = document.createElement('div');
	la13.innerHTML = '<br>';
}
var objectArraySort = function (keyName) {
 return function (objectN, objectM) {
  var valueN = objectN[keyName]
  var valueM = objectM[keyName]
  if (valueN < valueM) return 1
  else if (valueN > valueM) return -1
  else return 0
 }
}
var cnt=0;
function build_p(len){
	
	for(var i = 0; i < len; i++)
	{
		var tmp = function(i)
		{
			var ele = document.createElement('p');
			var ele2 = document.createElement('br');

			ele.id = 'newp'+ String(cnt+i);
			var k = document.getElementById("1");
			k.appendChild(ele);
			k.appendChild(ele2);
			
			build_text(ele.id,String(cnt+i));//data['时间'],data['街道'],data['社区'],data['来源'],data['问题'],data['类型'],data['部门']
			return 0;
		}(i);
	}cnt+= len;
	al_ele2.sort(objectArraySort('等级'));
	print();
};
function print(){
	
	for(var i = 0;i < al_ele2.length;i++ ){
		var tmp = function () {
				build_label2('newla'+ String(i)+'1' ,i,'时间','#808080');
				build_label2('newla'+ String(i)+'2',i,'街道','#FF7D00');
				build_label2('newla'+ String(i)+'3',i,'社区','#DDDD22');
				build_label2('newla'+ String(i)+'4',i,'来源','#00FF00');
				build_label2('newla'+ String(i)+'5',i,'问题','#FF0000');
				build_label2('newla'+ String(i)+'6',i,'类型','#00FFFF');
				build_label2('newla'+ String(i)+'7',i,'部门','#FF00FF');
				return 0;
		}(i)
	}
			
}

