
function buildhistogram(data_input){
var Data=data_input;

//console.log(Data);
var problem_type = Data['event_name'];

var count = problem_type.length;
delete Data.event_name;
var i = 0;
var all_kind = [];
for(var key in Data)
{
	var kind_detail = {};
	kind_detail.name = problem_type[i];
	kind_detail.type = 'bar';
	kind_detail.stack = '总量';
	kind_detail.label =  {
                normal: {
                    show: false,
                    position: 'insideRight'
				}
			},
	kind_detail.data = Data[key];
	all_kind.push(kind_detail);
	i++;
}
var dom = document.getElementById("secondcontainer");
var myChart = echarts.init(dom);
var app = {};
option = null;
app.title = '各街道民生事件情况';

option = {
    tooltip : {
        trigger: 'axis',
        axisPointer : {            // 坐标轴指示器，坐标轴触发有效
            type : 'shadow'        // 默认为直线，可选为：'line' | 'shadow'
        }
    },
    legend: {
			type: 'scroll',
			itemHeight:15,
    		orient: 'horizontal',
			padding: [80,80,30,30],
			animation: true,
    		x: 'center',
    		y: 'bottom',
    		itemGap: 10,
	// 		formatter: function (name) {
	// 			  if (name.length > 4) {
	// 				return name.slice(0,4) + '...';
	// 			  }
	// 			  else return name;
    // },
    		data:problem_type

        },
	toolbox: {
			x:'left',
			y:'top',
			show : true,
			feature : {
				mark : {show: true},
				dataView : {show: true, readOnly: false},
				magicType : {
					show: true,
					type: ['pie', 'funnel']
				},
				restore : {show: true},
				saveAsImage : {show: true}
			}
		},
		calculable : true,
    grid: {
        left: '3%',
        right: '5%',
        bottom: '15%',
        containLabel: true
    },
    xAxis:  {
       type: 'value',
    },
    yAxis: {
		type: 'category',
		data: ['碧岭街道','坑梓街道','龙田街道','马峦街道','坪山街道','石井街道','其他街道']
    },
	
	series:all_kind

};
// myChart.showLoading();
// myChart.hideLoading();
if (option && typeof option === "object") {
    myChart.setOption(option, true);
}//endfunction
}