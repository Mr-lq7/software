function buildrose(data) {
	var dom = document.getElementById("firstcontainer");
	var myChart = echarts.init(dom);
	var app = {};
	option = null;


	var type = new Array(0);
	var rosedata = [];
	var i = 0;
	for (var key in data) {
		var temp = {};
		type.push(key);
		temp['value'] = data[key];
		temp['name'] = key;
		rosedata.push(temp);
	}

	option = {
		title: {
			text: '民生分析',
			x: 'center'
		},
		tooltip: {
			trigger: 'item',
			formatter: "{a} <br/>{b} : {c} ({d}%)"
		},
		legend: {
			orient: 'vertical',
			left: 'left',
			data: type
		},
		toolbox: {
			show: true,
			feature: {
				mark: {show: true},
				dataView: {show: true, readOnly: false},
				magicType: {
					show: true,
					type: ['pie', 'funnel']
				},
				restore: {show: true},
				saveAsImage: {show: true}
			}
		},
		series: [
			{
				name: '民生分析',
				type: 'pie',
				radius: '55%',
				center: ['50%', '60%'],
				minAngle: 5,
				data: rosedata,
				itemStyle: {
					emphasis: {
						shadowBlur: 10,
						shadowOffsetX: 0,
						shadowColor: 'rgba(0, 0, 0, 0.5)'
					}
				}
			}
		]
	};

	if (option && typeof option === "object") {
		myChart.setOption(option, true);
	}
}// endfunction
