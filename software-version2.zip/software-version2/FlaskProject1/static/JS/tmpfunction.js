
function DisplayStatus_home(){
	var background1 = document.getElementById("page1");
	var background2 = document.getElementById("page2");
	var background3 = document.getElementById("page3");
	var background4 = document.getElementById("page4");
	var background5 = document.getElementById("page5");
	var background6 = document.getElementById("page6");
	var background7 = document.getElementById("page7");
	var background8 = document.getElementById("page8");
	var background9 = document.getElementById("page9");
	var homedivbegin = document.getElementById("pageone");
	var chart1div = document.getElementById("firstcharts");
	var chart2div = document.getElementById("secondcharts");
	var chart3div = document.getElementById("thirdcharts");
	var chart4div = document.getElementById("fouthcharts");
	var pass = document.getElementById("exchange");
	var homeheader = document.getElementById("home_header");
	var regist = document.getElementById("register");
	var effi = document.getElementById("efficiencychart");
	var get_back = document.getElementById("getbackpass");
	get_back.style.display = "none";
	effi.style.display = "none";
	regist.style.display = "none";
	homeheader.style.display = "block";
	pass.style.display = "none";
	homedivbegin.style.display = "block";
	chart1div.style.display = "none";
	chart2div.style.display = "none";
	chart3div.style.display = "none";
	chart4div.style.display = "none";

	background1.style.backgroundColor ="#e43c59";
	background2.style.backgroundColor = "#2f333e";
	background3.style.backgroundColor = "#2f333e";
	background4.style.backgroundColor = "#2f333e";
	background5.style.backgroundColor = "#2f333e";
	background6.style.backgroundColor = "#2f333e";
	background7.style.backgroundColor = "#2f333e";
	background8.style.backgroundColor = "#2f333e";
	background9.style.backgroundColor = "#2f333e";
		}
function chart1tmp(){
	var background1 = document.getElementById("page1");
	var background2 = document.getElementById("page2");
	var background3 = document.getElementById("page3");
	var background4 = document.getElementById("page4");
	var background5 = document.getElementById("page5");
	var background6 = document.getElementById("page6");
	var background7 = document.getElementById("page7");
	var background8 = document.getElementById("page8");
	var background9 = document.getElementById("page9");
	var homedivbegin = document.getElementById("pageone");
	var chart1div = document.getElementById("firstcharts");
	var chart2div = document.getElementById("secondcharts");
	var chart3div = document.getElementById("thirdcharts");
	var chart4div = document.getElementById("fouthcharts");
	var pass = document.getElementById("exchange");
	var homeheader = document.getElementById("home_header");
	var regist = document.getElementById("register");
	var effi = document.getElementById("efficiencychart");
	var get_back = document.getElementById("getbackpass");
	get_back.style.display = "none";
	effi.style.display = "none";
	regist.style.display = "none";
	homeheader.style.display = "block";
	pass.style.display = "none";
	homedivbegin.style.display = "none";
	chart1div.style.display = "block";
	chart2div.style.display = "none";
	chart3div.style.display = "none";
	chart4div.style.display = "none";
	background1.style.backgroundColor ="#2f333e";
	background2.style.backgroundColor = "#e43c59";
	background3.style.backgroundColor = "#2f333e";
	background4.style.backgroundColor = "#2f333e";
	background5.style.backgroundColor = "#2f333e";
	background6.style.backgroundColor = "#2f333e";
	background7.style.backgroundColor = "#2f333e";
	background8.style.backgroundColor = "#2f333e";
	background9.style.backgroundColor = "#2f333e";
}
function chart2tmp(){
	var background1 = document.getElementById("page1");
	var background2 = document.getElementById("page2");
	var background3 = document.getElementById("page3");
	var background4 = document.getElementById("page4");
	var background5 = document.getElementById("page5");
	var background6 = document.getElementById("page6");
	var background7 = document.getElementById("page7");
	var background8 = document.getElementById("page8");
	var background9 = document.getElementById("page9");
	var homedivbegin = document.getElementById("pageone");
	var chart1div = document.getElementById("firstcharts");
	var chart2div = document.getElementById("secondcharts");
	var chart3div = document.getElementById("thirdcharts");
	var chart4div = document.getElementById("fouthcharts");
	var pass = document.getElementById("exchange");
	var homeheader = document.getElementById("home_header");
	var regist = document.getElementById("register");
	var effi = document.getElementById("efficiencychart");
	var get_back = document.getElementById("getbackpass");
	get_back.style.display = "none";
	effi.style.display = "none";
	regist.style.display = "none";
	homeheader.style.display = "block";
	pass.style.display = "none";
	homedivbegin.style.display = "none";
	chart1div.style.display = "none";
	chart2div.style.display = "block";
	chart3div.style.display = "none";
	chart4div.style.display = "none";
	background1.style.backgroundColor ="#2f333e";
	background2.style.backgroundColor = "#2f333e";
	background3.style.backgroundColor = "#e43c59";
	background4.style.backgroundColor = "#2f333e";
	background5.style.backgroundColor = "#2f333e";
	background6.style.backgroundColor = "#2f333e";
	background7.style.backgroundColor = "#2f333e";
	background8.style.backgroundColor = "#2f333e";
	background9.style.backgroundColor = "#2f333e";
}
function chart3tmp(){
	var background1 = document.getElementById("page1");
	var background2 = document.getElementById("page2");
	var background3 = document.getElementById("page3");
	var background4 = document.getElementById("page4");
	var background5 = document.getElementById("page5");
	var background6 = document.getElementById("page6");
	var background7 = document.getElementById("page7");
	var background8 = document.getElementById("page8");
	var background9 = document.getElementById("page9");
	var homedivbegin = document.getElementById("pageone");
	var chart1div = document.getElementById("firstcharts");
	var chart2div = document.getElementById("secondcharts");
	var chart3div = document.getElementById("thirdcharts");
	var chart4div = document.getElementById("fouthcharts");
	var pass = document.getElementById("exchange");
	var homeheader = document.getElementById("home_header");
	var regist = document.getElementById("register");
	var effi = document.getElementById("efficiencychart");
	var get_back = document.getElementById("getbackpass");
	get_back.style.display = "none";
	effi.style.display = "none";
	regist.style.display = "none";
	homeheader.style.display = "block";
	pass.style.display = "none";
	homedivbegin.style.display ="none" ;
	chart1div.style.display = "none";
	chart2div.style.display = "none";
	chart3div.style.display = "block";
	chart4div.style.display = "none";
	background1.style.backgroundColor ="#2f333e";
	background2.style.backgroundColor = "#2f333e";
	background3.style.backgroundColor = "#2f333e";
	background4.style.backgroundColor = "#e43c59";
	background5.style.backgroundColor = "#2f333e";
	background6.style.backgroundColor = "#2f333e";
	background7.style.backgroundColor = "#2f333e";
	background8.style.backgroundColor = "#2f333e";
	background9.style.backgroundColor = "#2f333e";
}
function chart4tmp(){
	var background1 = document.getElementById("page1");
	var background2 = document.getElementById("page2");
	var background3 = document.getElementById("page3");
	var background4 = document.getElementById("page4");
	var background5 = document.getElementById("page5");
	var background6 = document.getElementById("page6");
	var background7 = document.getElementById("page7");
	var background8 = document.getElementById("page8");
	var background9 = document.getElementById("page9");
	var homedivbegin = document.getElementById("pageone");
	var chart1div = document.getElementById("firstcharts");
	var chart2div = document.getElementById("secondcharts");
	var chart3div = document.getElementById("thirdcharts");
	var chart4div = document.getElementById("fouthcharts");
	var pass = document.getElementById("exchange");
	var homeheader = document.getElementById("home_header");
	var regist = document.getElementById("register");
	var effi = document.getElementById("efficiencychart");
	var get_back = document.getElementById("getbackpass");
	get_back.style.display = "none";
	effi.style.display = "none";
	regist.style.display = "none";
	homeheader.style.display = "block";
	pass.style.display = "none";
	homedivbegin.style.display = "none";
	chart1div.style.display = "none";
	chart2div.style.display = "none";
	chart3div.style.display = "none";
	chart4div.style.display = "block";
	background1.style.backgroundColor ="#2f333e";
	background2.style.backgroundColor = "#2f333e";
	background3.style.backgroundColor = "#2f333e";
	background4.style.backgroundColor = "#2f333e";
	background5.style.backgroundColor = "#e43c59";
	background6.style.backgroundColor = "#2f333e";
	background7.style.backgroundColor = "#2f333e";
	background8.style.backgroundColor = "#2f333e";
	background9.style.backgroundColor = "#2f333e";
}
function passwordexchangetmp(){
	var background1 = document.getElementById("page1");
	var background2 = document.getElementById("page2");
	var background3 = document.getElementById("page3");
	var background4 = document.getElementById("page4");
	var background5 = document.getElementById("page5");
	var background6 = document.getElementById("page6");
	var background7 = document.getElementById("page7");
	var background8 = document.getElementById("page8");
	var background9 = document.getElementById("page9");
	var homedivbegin = document.getElementById("pageone");
	var chart1div = document.getElementById("firstcharts");
	var chart2div = document.getElementById("secondcharts");
	var chart3div = document.getElementById("thirdcharts");
	var chart4div = document.getElementById("fouthcharts");
	var pass = document.getElementById("exchange");
	var homeheader = document.getElementById("home_header");
	var regist = document.getElementById("register");
	var effi = document.getElementById("efficiencychart");
	var get_back = document.getElementById("getbackpass");
	var radio_checked = document.getElementsByClassName("car")[1];
    radio_checked.checked = true;
	get_back.style.display = "none";
	effi.style.display = "none";
	regist.style.display = "none";
	homeheader.style.display = "none";
	pass.style.display = "block";
	homedivbegin.style.display = "none";
	chart1div.style.display = "none";
	chart2div.style.display = "none";
	chart3div.style.display = "none";
	chart4div.style.display = "none";
	background1.style.backgroundColor ="#2f333e";
	background2.style.backgroundColor = "#2f333e";
	background3.style.backgroundColor = "#2f333e";
	background4.style.backgroundColor = "#2f333e";
	background5.style.backgroundColor = "#2f333e";
	background6.style.backgroundColor = "#e43c59";
	background7.style.backgroundColor = "#2f333e";
	background8.style.backgroundColor = "#2f333e";
	background9.style.backgroundColor = "#2f333e";
}
function passregistertmp(){
	var background1 = document.getElementById("page1");
	var background2 = document.getElementById("page2");
	var background3 = document.getElementById("page3");
	var background4 = document.getElementById("page4");
	var background5 = document.getElementById("page5");
	var background6 = document.getElementById("page6");
	var background7 = document.getElementById("page7");
	var background8 = document.getElementById("page8");
	var background9 = document.getElementById("page9");
	var homedivbegin = document.getElementById("pageone");
	var chart1div = document.getElementById("firstcharts");
	var chart2div = document.getElementById("secondcharts");
	var chart3div = document.getElementById("thirdcharts");
	var chart4div = document.getElementById("fouthcharts");
	var pass = document.getElementById("exchange");
	var homeheader = document.getElementById("home_header");
	var regist = document.getElementById("register");
	var effi = document.getElementById("efficiencychart");
	var get_back = document.getElementById("getbackpass");
	get_back.style.display = "none";
	effi.style.display = "none";
	regist.style.display = "block";
	homeheader.style.display = "none";
	pass.style.display = "none";
	homedivbegin.style.display = "none";
	chart1div.style.display = "none";
	chart2div.style.display = "none";
	chart3div.style.display = "none";
	chart4div.style.display = "none";
	background1.style.backgroundColor ="#2f333e";
	background2.style.backgroundColor = "#2f333e";
	background3.style.backgroundColor = "#2f333e";
	background4.style.backgroundColor = "#2f333e";
	background5.style.backgroundColor = "#2f333e";
	background6.style.backgroundColor = "#2f333e";
	background7.style.backgroundColor = "#e43c59";
	background8.style.backgroundColor = "#2f333e";
	background9.style.backgroundColor = "#2f333e";
}
function efficiency_chartstmp(){
	var background1 = document.getElementById("page1");
	var background2 = document.getElementById("page2");
	var background3 = document.getElementById("page3");
	var background4 = document.getElementById("page4");
	var background5 = document.getElementById("page5");
	var background6 = document.getElementById("page6");
	var background7 = document.getElementById("page7");
	var background8 = document.getElementById("page8");
	var background9 = document.getElementById("page9");
	var homedivbegin = document.getElementById("pageone");
	var chart1div = document.getElementById("firstcharts");
	var chart2div = document.getElementById("secondcharts");
	var chart3div = document.getElementById("thirdcharts");
	var chart4div = document.getElementById("fouthcharts");
	var pass = document.getElementById("exchange");
	var homeheader = document.getElementById("home_header");
	var regist = document.getElementById("register");
	var effi = document.getElementById("efficiencychart");
	var get_back = document.getElementById("getbackpass");
	get_back.style.display = "none";
	effi.style.display = "block";
	regist.style.display = "none";
	homeheader.style.display = "block";
	pass.style.display = "none";
	homedivbegin.style.display = "none";
	chart1div.style.display = "none";
	chart2div.style.display = "none";
	chart3div.style.display = "none";
	chart4div.style.display = "none";
	background1.style.backgroundColor ="#2f333e";
	background2.style.backgroundColor = "#2f333e";
	background3.style.backgroundColor = "#2f333e";
	background4.style.backgroundColor = "#2f333e";
	background5.style.backgroundColor = "#2f333e";
	background6.style.backgroundColor = "#2f333e";
	background7.style.backgroundColor = "#2f333e";
	background8.style.backgroundColor = "#e43c59";
	background9.style.backgroundColor = "#2f333e";
}
function getbackpasswordtmp(){
	var background1 = document.getElementById("page1");
	var background2 = document.getElementById("page2");
	var background3 = document.getElementById("page3");
	var background4 = document.getElementById("page4");
	var background5 = document.getElementById("page5");
	var background6 = document.getElementById("page6");
	var background7 = document.getElementById("page7");
	var background8 = document.getElementById("page8");
	var background9 = document.getElementById("page9");
	var homedivbegin = document.getElementById("pageone");
	var chart1div = document.getElementById("firstcharts");
	var chart2div = document.getElementById("secondcharts");
	var chart3div = document.getElementById("thirdcharts");
	var chart4div = document.getElementById("fouthcharts");
	var pass = document.getElementById("exchange");
	var homeheader = document.getElementById("home_header");
	var regist = document.getElementById("register");
	var effi = document.getElementById("efficiencychart");
	var get_back = document.getElementById("getbackpass");
	get_back.style.display = "block";
	effi.style.display = "none";
	regist.style.display = "none";
	homeheader.style.display = "none";
	pass.style.display = "none";
	homedivbegin.style.display = "none";
	chart1div.style.display = "none";
	chart2div.style.display = "none";
	chart3div.style.display = "none";
	chart4div.style.display = "none";
	background1.style.backgroundColor ="#2f333e";
	background2.style.backgroundColor = "#2f333e";
	background3.style.backgroundColor = "#2f333e";
	background4.style.backgroundColor = "#2f333e";
	background5.style.backgroundColor = "#2f333e";
	background6.style.backgroundColor = "#2f333e";
	background7.style.backgroundColor = "#2f333e";
	background8.style.backgroundColor = "#2f333e";
	background9.style.backgroundColor = "#e43c59";
}
function chartsshow(){
		var homedivshow = document.getElementById("pageone");
		var fiestchartdivshow = document.getElementById("firstcharts");
		var secondchartdivshow = document.getElementById("secondcharts");
		var thridchartdivshow = document.getElementById("thirdcharts");
		var fouthchartdivshow = document.getElementById("fouthcharts");
		var effi = document.getElementById("efficiencychart");
		var daytmp={year: 2018, month: 10, day: 30};
    if(homedivshow.style.display == "block")
    {
        //console.log("主页");
    }else if(fiestchartdivshow.style.display == "block"){
        if(isObjectValueEqual(getday2.time2, daytmp)){
         DisplayStatus_charts1();
        }
    }else if(secondchartdivshow.style.display == "block"){
        if(isObjectValueEqual(getday3.time2, daytmp)){
        DisplayStatus_charts2();
        }
    }else if(thridchartdivshow.style.display == "block"){
        if(isObjectValueEqual(getday4.time2, daytmp)){
        DisplayStatus_charts3();
        }
    }else if(fouthchartdivshow.style.display ==  "block"){
        if(isObjectValueEqual(getday5.time2, daytmp)){
        DisplayStatus_charts4();
        }
    }else if(effi.style.display ==  "block"){
        if(isObjectValueEqual(getday6.time2, daytmp)){
        efficiency_charts();
        }
    }
}