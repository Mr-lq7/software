//jQuery time
var registername_tmp;
var current_fs, next_fs, previous_fs; //fieldsets
var left, opacity, scale; //fieldset properties which we will animate
var animating; //flag to prevent quick multi-click glitches

function messagecheck(){
	var counter_ = document.getElementsByName('Counter')[0].value;
	var password_ = document.getElementsByName('pass')[0].value;
	var cpassword_ = document.getElementsByName('cpass')[0].value;

	registername_tmp=counter_;

	if(!counter_ || !password_){
		alert('信息不完整');
		return false;
	}

	if(password_ != cpassword_){
		alert('输入密码不一致');
		return false;
	}

	var reg = /^(?=.*[a-zA-Z])(?=.*\d)(?=.*[~!@#$%^&*()_+`\-={}:";'<>?,.\/]).{4,16}$/;
	var flag = reg.test(password_);
	if(flag == false){
		alert("密码必须由 4-16位字母、数字、特殊符号线组成.");
		return false;
	}

	if(animating) return false;
	animating = true;

	return true;
}

// $("#registersubmit").click(function(){
// 	var email_ = document.getElementById("registerpassword").value;
//
//
//
// 	if(!email_){
// 		alert('信息不完整');
// 		return false;
// 	}
// 	var e_reg = /^([a-zA-Z]|[0-9])(\w|\-)+@[a-zA-Z0-9]+\.([a-zA-Z]{2,4})$/;
// 	if(e_reg.test(email_) == false){
// 		alert("邮箱格式不正确.");
// 		email_ = null;
// 		return false;
// 	}


	// if(animating) return false;
	// animating = true;
	//
	// current_fs = $(this).parent();
	// next_fs = $(this).parent().next();
	//
	// //activate next step on progressbar using the index of next_fs
	// $("#progressbar li").eq($("fieldset").index(next_fs)).addClass("active");
	//
	// //show the next fieldset
	// next_fs.show();
	// //hide the current fieldset with style
	// current_fs.animate({opacity: 0}, {
	// 	step: function(now, mx) {
	// 		//as the opacity of current_fs reduces to 0 - stored in "now"
	// 		//1. scale current_fs down to 80%
	// 		scale = 1 - (1 - now) * 0.2;
	// 		//2. bring next_fs from the right(50%)
	// 		left = (now * 50)+"%";
	// 		//3. increase opacity of next_fs to 1 as it moves in
	// 		opacity = 1 - now;
	// 		current_fs.css({'transform': 'scale('+scale+')'});
	// 		next_fs.css({'left': left, 'opacity': opacity});
	// 	},
	// 	duration: 800,
	// 	complete: function(){
	// 		current_fs.hide();
	// 		animating = false;
	// 	},
	// 	//this comes from the custom easing plugin
	// 	easing: 'easeInOutBack'
	// });
//});

$(".previous").click(function(){
	if(animating) return false;
	animating = true;
	
	current_fs = $(this).parent();
	previous_fs = $(this).parent().prev();

	$("#progressbar li").eq($("fieldset").index(current_fs)).removeClass("active");
	previous_fs.show();
	current_fs.animate({opacity: 0}, {
		step: function(now, mx) {
			scale = 0.8 + (1 - now) * 0.2;
			left = ((1-now) * 50)+"%";
			opacity = 1 - now;
			current_fs.css({'left': left});
			previous_fs.css({'transform': 'scale('+scale+')', 'opacity': opacity});
		},
		duration: 800,
		complete: function(){
			current_fs.hide();
			animating = false;
		},
		easing: 'easeInOutBack'
	});
});